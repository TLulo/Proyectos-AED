

#include <stdio.h>
#include "array_helpers.h"
#include "weather_utils.h"
#include <limits.h>


int min(int a, int b){
  return (a > b) ? b : a;
}
int max(int a, int b){
  return (a < b) ? b : a;
}

int min_temp(WeatherTable array){
  int res = INT_MAX;
  for (int year = 0; year < YEARS; year++){
    for(month_t month = january; month <= december; month++){
      for(int day = 0; day < DAYS; day++){
        res = min(array[year][month][day]._min_temp, res); 
      }
    }
  }
  return res;
}

void max_temp_per_year(WeatherTable a, int array[]){
  
  for (unsigned int year = 0; year < YEARS; year++){
    int res = INT_MIN;
    for(month_t month = january; month <= december; month++){
      for(int day = 0; day < DAYS; day++){
   
        res = max(a[year][month][day]._max_temp, res);
      
      }
    }
    array[year] = res; 
  }
}


void max_rainfall_per_month(WeatherTable a, int array[]){
  int res_month;
  
  for (int year = 0; year < YEARS; year++){
    unsigned int max_rain = 0;

    for(int month = 0; month < MONTHS; month++){
      unsigned rain_sum = 0;
      
      for(int day = 0; day < DAYS; day++){
      rain_sum = a[year][month][day]._rainfall + rain_sum;
      }
      
      if (max_rain <= rain_sum){
      res_month = month;
      max_rain = rain_sum;
      }
    }
    array[year] = res_month; 
  }
}
